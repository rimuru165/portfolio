import React from 'react';
import './Contact.css';

function Contact() {
  return (
    <div className="contact-container">
      <h1>Contact</h1>
      <div className="contact-box">
        <p><strong>Phone:</strong> 0999-905-1550</p>
        <p><strong>Email:</strong> jannointo.com@gmail.com</p>
      </div>
    </div>
  );
}

export default Contact;
